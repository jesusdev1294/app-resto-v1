import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-especialidades',
  templateUrl: './especialidades.page.html',
  styleUrls: ['./especialidades.page.scss'],
})
export class EspecialidadesPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
